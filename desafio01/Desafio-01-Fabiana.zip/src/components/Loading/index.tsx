import { ReactComponent as Pokeball } from '../../assets/pokeball.svg';

export function Loading() {
  return <Pokeball className="loader" />;
}
