export function TicTacToe() {
  return <div>Jogo da Velha</div>;
}
