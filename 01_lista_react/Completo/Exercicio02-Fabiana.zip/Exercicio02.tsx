import style from './Exercicio02.module.css';

type ChatBaloonProps = {
  type: 'sender' | 'receiver';
  imageUrl?: string;
  text?: string;
};

function Exercicio02({ type, imageUrl, text }: ChatBaloonProps) {
  return (
    <div
      className={`${style.chatBallon} ${
        type === 'sender' ? style.sender : style.receiver
      }`}
    >
      {text ? text : 'Texto Padrão'}
      {imageUrl && (
        <img src={imageUrl} alt="image" className={style.imageSize} />
      )}
    </div>
  );
}

export default Exercicio02;
