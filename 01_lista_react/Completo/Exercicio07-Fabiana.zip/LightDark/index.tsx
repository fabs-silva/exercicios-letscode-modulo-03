import { useState } from "react";
import Header from "./components/Header";
import Main from "./components/Main";
import "./styles.css";

export interface ThemeProps {
  theme: "light" | "dark";
}

function LightDark() {
  const [isClicked, setIsClicked] = useState<boolean>(false);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  function handleButtonClick() {
    isClicked ? setTheme("light") : setTheme("dark");
    setIsClicked(!isClicked);
  }
  return (
    <div className={theme === "light" ? "lightBackground" : "darkBackground"}>
      <h1 className={theme === "light" ? "lightTitle" : "darkTitle"}>
        LightDark
      </h1>
      <Header theme={theme} />
      <Main theme={theme} />
      <button onClick={handleButtonClick}>Alterar Tema</button>
    </div>
  );
}

export default LightDark;
