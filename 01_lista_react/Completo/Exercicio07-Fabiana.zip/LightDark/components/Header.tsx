import React from "react";
import { ThemeProps } from "..";

function Header({ theme, ...rest }: ThemeProps) {
  return (
    <div>
      <h1 className={theme === "light" ? "lightTitle" : "darkTitle"}>Header</h1>
    </div>
  );
}

export default Header;
