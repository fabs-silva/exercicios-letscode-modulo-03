import { Link } from 'react-router-dom';

export function Menu() {
  return (
    <>
      <Link to="/">Home</Link>
      <Link to="/galeria">Galeria de Imagens</Link>
      <Link to="/chat">Chat</Link>
    </>
  );
}
