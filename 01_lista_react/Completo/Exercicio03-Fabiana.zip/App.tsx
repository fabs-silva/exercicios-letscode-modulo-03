import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Menu } from './components/Menu';
import Chat from './pages/Chat';
import Home from './pages/Home';
import ImageGallery from './pages/ImageGallery';

function App() {
  return (
    <BrowserRouter>
      <Menu />
      <Routes>
        <Route path="/" element={<App />} />
        <Route index element={<Home />} />
        <Route path="/galeria" element={<ImageGallery />} />
        <Route path="/chat" element={<Chat type="sender" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
